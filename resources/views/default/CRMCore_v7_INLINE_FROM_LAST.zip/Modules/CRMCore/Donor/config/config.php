<?php

return [
    'name' => 'CRMCore',
];
