<?php

return [
    'name' => 'Complaint'
];
