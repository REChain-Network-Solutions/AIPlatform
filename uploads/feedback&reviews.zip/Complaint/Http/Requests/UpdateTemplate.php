<?php

namespace Modules\Complaint\Http\Requests;

use App\Http\Requests\CoreRequest;

class UpdateTemplate extends CoreRequest
{

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'reply_heading' => 'required',
            'reply_text' => 'required'
        ];
    }

}
