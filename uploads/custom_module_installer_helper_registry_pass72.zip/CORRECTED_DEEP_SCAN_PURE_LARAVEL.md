# Custom Module Installer - Deep Scan Analysis CORRECTED
## Pure Laravel Focus - No CodeIgniter

**Clarification**: You're building a **Laravel-to-Laravel** custom module installer. The references to "WorkSuite" in the codebase are read-only metadata/audit points, NOT integration requirements.

---

## Architecture: What You Actually Have

Your installer is a **validation + safe-fix orchestration layer** for custom Laravel modules. The system:

1. **Analyzes** uploaded custom modules against manifest spec
2. **Validates** against the running system (no collisions)
3. **Snapshots** pre-install state (for rollback)
4. **Installs** module files to `Modules/{ModuleName}/`
5. **Repairs** post-install (permissions, routes, settings)
6. **Tracks** everything in the database

This is **sound architecture**. The gaps are about completeness, not direction.

---

## Real Critical Issues (Ranked)

### CRITICAL #1: Safe-Fix Actions Are Planned But Not Executed 🔴

**Current state** (CustomModuleSafeFixer.php, lines 20–52):
```php
public function plan(ModuleAnalysisResult $analysis, array $options = []): array
{
    // ... generates array of actions
    // Line 40: "Recommended next pass: bind these actions to concrete SQL / service operations"
}
```

**Translation**: You're building the *plan*, not running it.

**What's missing**:
```php
// Current: describe() only
QueuePermissionRepairAction::describe() → ['name' => 'repair_permissions', ...]

// Missing: execute() + rollback()
QueuePermissionRepairAction::execute($moduleName) → actually insert permissions
QueuePermissionRepairAction::rollback($moduleName) → remove them
```

**Why it matters**: Post-install, the module's permissions/routes exist in the ZIP manifest but NOT in your database yet. Safe-fix is supposed to sync them. Right now it just says "here's the plan."

**Evidence of incompleteness**:
- CustomModuleController::store() (lines 105–180) never calls an executor
- No dispatch to queue jobs
- No SQL mutations committed
- The controller just moves files and logs success

---

### CRITICAL #2: State Tracking Can't Handle Partial Failures 🔴

**Problem**: Installation has no atomicity. If:
1. Module files move ✅
2. Permission repair starts ⚠️ but fails halfway
3. Route registration fails ❌
4. System state is now **corrupted** (partial install)

**Current**: You log the failure but have **no rollback mechanism**. Module files are on disk, but metadata is inconsistent.

**Schema issue**: Duplicate migrations create ambiguity:
```
2026_03_22_000001_create_custom_module_install_logs_table.php
2026_03_22_000011_create_custom_module_install_logs_table.php  ← DUPLICATE
```

Which one ran? Which columns exist? This breaks state tracking.

---

### CRITICAL #3: Pre-Install Validation Has Blind Spots 🔴

**Missing validators**:

1. **Permission Key Collision**  
   Module A adds permission `edit_invoices`  
   Your core also has `edit_invoices`  
   → Silent failure. No blocking check exists.

2. **Route URI Collision**  
   Module route: `POST /admin/reports`  
   Core route: `POST /admin/reports`  
   → Both register. Unpredictable behavior wins.

3. **File System Checks**  
   - Disk full? No check.
   - `Modules/` not writable? No check.
   - ZIP corrupted? No checksum validation.

**Current state** (CustomModuleAnalyzer.php, lines 21–78):
- Checks manifest ✅
- Checks routes ✅
- Checks sidebar ✅
- Checks permissions ✅
- Checks doctor panels ✅
- **Checks for collisions with live system?** ❌

---

### CRITICAL #4: Blade Template Tower of Babel 🟡

**Issue**: 60+ Blade templates, unclear data contracts.

Examples:
```
resources/views/custom-modules/partials/menu-diff.blade.php
resources/views/custom-modules/partials/menu-eligibility.blade.php
resources/views/custom-modules/partials/menu-risk.blade.php
resources/views/custom-modules/partials/sidebar-readiness.blade.php
resources/views/custom-modules/partials/permission-matrix.blade.php
...and 55 more
```

**Problems**:
1. **No registry** - Which are required vs. optional? Unknown.
2. **No validation** - Each expects different `$data` shape. Typo = silent fail.
3. **No versioning** - If you refactor a template, which views still expect the old signature?
4. **Inline styles** - 70+ lines of `!important` flags in install.blade.php (signs of CSS fragility)

**Example** (install.blade.php, lines 34–39):
```blade
.module-diagnostic-report .alert-light,
#install-process .alert-light {
    background: #111a33 !important;
    border-color: #263357 !important;
    color: #dfe8ff !important;
}
```

Why `!important`? Probably cascading conflicts from multiple CSS files.

---

### CRITICAL #5: Upload Security Has Gaps 🔴

**What's missing**:
1. **No ZIP validation** - Corrupt files aren't detected
2. **No checksum** - Can't verify upload integrity
3. **No security scan** - Shell code isn't flagged
4. **No cleanup** - Old uploads sit forever, filling disk
5. **No quota** - Can upload infinite ZIPs

**Danger example**:
```php
// Attacker uploads ZIP with:
// Modules/EvilModule/app/Console/Commands/Shell.php
// Contains: exec($_GET['cmd'])

// Your installer:
// - Extracts it ✅
// - Analyzes it (no security scan) ✅
// - Installs it ✅
// - Done. Now the shell works.
```

---

### CRITICAL #6: Routes Aren't Actually Validated Against Live System 🔴

**RouteAnalyzer** (app/Services/CustomModules/Analyzers/RouteAnalyzer.php):
- Reads routes from the ZIP ✅
- Checks they're well-formed ✅
- **Checks if they collide with core/other modules?** ❌

**What should happen**:
```php
// Before install, check:
$newRoutes = extractRoutesFromModule('CustomModule');
$existingRoutes = Route::getRoutes();

foreach ($newRoutes as $route) {
    if ($existingRoutes->hasRoute($route['uri'])) {
        error("Route {$route['uri']} already exists");
    }
}
```

**What actually happens**:
- RouteAnalyzer just parses the ZIP
- No query against live Route::getRoutes()
- Both modules register their routes
- Last one to load wins (unpredictable)

---

### CRITICAL #7: Safe-Fix Actions Aren't Queued or Journaled 🟡

**Current** (QueuePermissionRepairAction.php):
```php
class QueuePermissionRepairAction {
    public function describe(): array {
        return [...];  // Just metadata
    }
}
```

**Missing**:
```php
public function execute(string $moduleName): array {
    // Actually insert permissions into DB
    // Return what changed
}

public function rollback(string $moduleName): array {
    // Reverse the changes
}
```

Plus: **No persistent record** of which actions ran, what they changed, what succeeded vs. failed.

---

## Architecture Assessment

### What Works Well ✅

1. **Modular Analyzers** - Each analyzer is independent and testable
   - ManifestAnalyzer, RouteAnalyzer, SidebarAnalyzer, PermissionAnalyzer
   - Clean separation of concerns

2. **DTO Pattern** - ModuleAnalysisResult is a proper data container
   - Strongly typed (constructor promotion)
   - Immutable by convention
   - Clear contract

3. **Safe-Fix Skeleton** - The action pattern is correct
   - Just needs execution binding

4. **Component Structure** - Views/Controllers/Services are properly split
   - Routes are organized
   - Middleware is applied

5. **Doctor Diagnostic System** - ModuleDoctor has 80+ specialized services
   - Some never used by installer, but that's okay (for future expansion)

### What Doesn't Work ❌

1. **No Execution Binding** - Plan without do
2. **No Collision Detection** - Pre-install validation incomplete
3. **Duplicate State** - Migrations broken
4. **No Security Scanning** - Uploads unchecked
5. **No Rollback** - Partial failures corrupt system
6. **Template Chaos** - 60 templates, no registry
7. **No Upload Cleanup** - Disk fills up

---

## Specific Recommendations (Pure Laravel, No CodeIgniter)

### Phase 1: Fix State Tracking (Critical, 1 day)

**1.1 Clean Migrations**
```bash
# Delete duplicates (keep 000X, delete 001X)
rm database/migrations/2026_03_22_000011_*.php
rm database/migrations/2026_03_22_000012_*.php
rm database/migrations/2026_03_22_000013_*.php

# Verify
php artisan migrate --path=database/migrations
```

**1.2 Enhance Schema**
```php
// database/migrations/2026_03_24_enhance_custom_module_installs.php
Schema::table('custom_module_installs', function (Blueprint $table) {
    if (!Schema::hasColumn('custom_module_installs', 'pre_install_snapshot')) {
        $table->json('pre_install_snapshot')->nullable();
    }
    if (!Schema::hasColumn('custom_module_installs', 'applied_repairs')) {
        $table->json('applied_repairs')->nullable();
    }
    if (!Schema::hasColumn('custom_module_installs', 'validation_score')) {
        $table->integer('validation_score')->default(0);
    }
    if (!Schema::hasColumn('custom_module_installs', 'can_rollback')) {
        $table->boolean('can_rollback')->default(false);
    }
});
```

---

### Phase 2: Bind Safe-Fix Actions (Critical, 2 days)

**2.1 Add execute() to Each Action**
```php
// app/Services/CustomModules/Actions/QueuePermissionRepairAction.php
class QueuePermissionRepairAction {
    
    public function execute(string $moduleName): array {
        try {
            $manifest = $this->loadManifest($moduleName);
            $inserted = 0;
            
            foreach (($manifest['permissions'] ?? []) as $perm) {
                DB::table('permissions')->updateOrInsert(
                    ['permission_key' => $perm['key']],
                    ['module' => $moduleName, 'display_name' => $perm['label'] ?? '']
                );
                $inserted++;
            }
            
            return ['success' => true, 'inserted' => $inserted];
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    public function rollback(string $moduleName): array {
        try {
            $deleted = DB::table('permissions')
                ->where('module', $moduleName)
                ->delete();
            
            return ['success' => true, 'deleted' => $deleted];
        } catch (\Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    private function loadManifest(string $moduleName): array {
        $path = base_path("Modules/{$moduleName}/module.json");
        return json_decode(file_get_contents($path), true) ?? [];
    }
}
```

**2.2 Create Executor Orchestrator**
```php
// app/Services/CustomModules/SafeFixActionExecutor.php
class SafeFixActionExecutor {
    
    public function __construct(
        private QueuePermissionRepairAction $permissionAction,
        private QueuePackageBridgeRepairAction $packageAction,
        private QueueCompanyModuleSettingsRepairAction $companyAction,
        private QueueCacheClearAction $cacheAction,
    ) {}
    
    public function executeAll(string $moduleName, array $selectedRepairs = []): array {
        $results = [];
        $failed = [];
        
        $actions = [
            'repair_permissions' => $this->permissionAction,
            'repair_package_bridge' => $this->packageAction,
            'repair_company_settings' => $this->companyAction,
            'clear_caches' => $this->cacheAction,
        ];
        
        foreach ($actions as $name => $action) {
            if (!($selectedRepairs[$name] ?? true)) {
                continue; // Skip if not selected
            }
            
            try {
                $result = $action->execute($moduleName);
                $results[$name] = $result;
                
                if (!$result['success']) {
                    $failed[$name] = $result['error'];
                }
            } catch (\Exception $e) {
                $results[$name] = ['success' => false, 'error' => $e->getMessage()];
                $failed[$name] = $e->getMessage();
            }
        }
        
        return [
            'all_success' => empty($failed),
            'executed' => $results,
            'failed' => $failed,
        ];
    }
}
```

**2.3 Update Controller to Execute**
```php
// CustomModuleController::store() - lines 105–180
public function store(Request $request) {
    $analysis = $this->analyzeUploadedModule($request->filePath, true);
    
    if (!($analysis['status'] ?? false)) {
        return Reply::dataOnly(['status' => 'fail', 'message' => '...']);
    }
    
    $moduleName = $analysis['module_name'];
    
    // Install files
    File::moveDirectory($tmpPath, base_path("Modules/{$moduleName}"), true);
    
    // NEW: Execute safe-fix actions
    $executor = app(SafeFixActionExecutor::class);
    $repairResult = $executor->executeAll($moduleName, [
        'repair_permissions' => true,
        'repair_package_bridge' => true,
        'repair_company_settings' => true,
        'clear_caches' => true,
    ]);
    
    if (!$repairResult['all_success']) {
        // Log failures but don't fail install
        \Log::warning("Module {$moduleName} had repair failures", $repairResult['failed']);
    }
    
    // Record state
    ModuleInstallLog::create([
        'module_name' => $moduleName,
        'status' => 'installed',
        'applied_repairs' => $repairResult['executed'],
    ]);
    
    return Reply::dataOnly(['status' => 'success', ...]);
}
```

---

### Phase 3: Add Collision Validators (Critical, 2 days)

**3.1 Permission Collision Validator**
```php
// app/Services/CustomModules/Validators/PermissionCollisionValidator.php
class PermissionCollisionValidator {
    
    public function validate(string $filePath): array {
        $manifest = $this->extractManifest($filePath);
        $newPermissions = $manifest['permissions'] ?? [];
        
        $issues = [];
        
        foreach ($newPermissions as $perm) {
            $existing = DB::table('permissions')
                ->where('permission_key', $perm['key'])
                ->first();
            
            if ($existing && $existing->module !== $this->extractModuleName($filePath)) {
                $issues[] = [
                    'severity' => 'error',
                    'code' => 'PERMISSION_COLLISION',
                    'message' => "Permission '{$perm['key']}' already exists in module '{$existing->module}'",
                ];
            }
        }
        
        return ['valid' => empty($issues), 'issues' => $issues];
    }
}
```

**3.2 Route Collision Validator**
```php
// app/Services/CustomModules/Validators/RouteCollisionValidator.php
class RouteCollisionValidator {
    
    public function validate(string $filePath): array {
        $manifest = $this->extractManifest($filePath);
        $newRoutes = $manifest['routes'] ?? [];
        
        $issues = [];
        $existingRoutes = Route::getRoutes();
        
        foreach ($newRoutes as $route) {
            foreach ($existingRoutes as $existing) {
                if ($this->routesConflict($route, $existing)) {
                    $issues[] = [
                        'severity' => 'error',
                        'code' => 'ROUTE_COLLISION',
                        'message' => "Route '{$route['uri']}' already registered",
                    ];
                }
            }
        }
        
        return ['valid' => empty($issues), 'issues' => $issues];
    }
    
    private function routesConflict($new, $existing): bool {
        return $new['uri'] === $existing->uri && 
               in_array($new['method'], $existing->methods);
    }
}
```

**3.3 Integrate into Pre-Install**
```php
// CustomModuleController::store() - add before install
$permissionValidator = app(PermissionCollisionValidator::class);
$routeValidator = app(RouteCollisionValidator::class);

$permIssues = $permissionValidator->validate($filePath);
$routeIssues = $routeValidator->validate($filePath);

if (!$permIssues['valid'] || !$routeIssues['valid']) {
    return Reply::dataOnly([
        'status' => 'fail',
        'message' => 'Module has collision conflicts',
        'permission_issues' => $permIssues['issues'],
        'route_issues' => $routeIssues['issues'],
    ]);
}
```

---

### Phase 4: Add Security Scanning (High, 1 day)

**4.1 ZIP Security Validator**
```php
// app/Services/CustomModules/Validators/SecurityScanValidator.php
class SecurityScanValidator {
    
    public function validate(string $filePath): array {
        $issues = [];
        
        // 1. Verify ZIP is readable
        if (!$this->isValidZip($filePath)) {
            return [
                'valid' => false,
                'issues' => [['severity' => 'error', 'message' => 'ZIP file is corrupted']],
            ];
        }
        
        // 2. Extract and scan for shell patterns
        $tempDir = storage_path('temp/' . uniqid());
        $zip = new \ZipArchive();
        $zip->open($filePath);
        $zip->extractTo($tempDir);
        $zip->close();
        
        $phpFiles = File::allFiles($tempDir);
        $dangerousPatterns = [
            'shell_exec', 'exec', 'system', 'passthru', 'proc_open', 'eval'
        ];
        
        foreach ($phpFiles as $file) {
            $content = file_get_contents($file->getPathname());
            
            foreach ($dangerousPatterns as $pattern) {
                if (str_contains($content, $pattern)) {
                    $issues[] = [
                        'severity' => 'error',
                        'code' => 'SHELL_PATTERN',
                        'message' => "Dangerous function '{$pattern}' found in {$file->getFilename()}",
                    ];
                }
            }
        }
        
        // 3. Check for path traversal attempts
        foreach (File::allFiles($tempDir) as $file) {
            if (str_contains($file->getRelativePath(), '../')) {
                $issues[] = [
                    'severity' => 'error',
                    'code' => 'PATH_TRAVERSAL',
                    'message' => "Suspicious path: {$file->getRelativePath()}",
                ];
            }
        }
        
        // Cleanup
        File::deleteDirectory($tempDir);
        
        return [
            'valid' => empty(array_filter($issues, fn($i) => $i['severity'] === 'error')),
            'issues' => $issues,
        ];
    }
    
    private function isValidZip(string $filePath): bool {
        $zip = new \ZipArchive();
        return $zip->open($filePath) === true;
    }
}
```

**4.2 Add to Pre-Install Chain**
```php
$securityValidator = app(SecurityScanValidator::class);
$securityResult = $securityValidator->validate($filePath);

if (!$securityResult['valid']) {
    return Reply::dataOnly([
        'status' => 'fail',
        'message' => 'Security scan failed',
        'security_issues' => $securityResult['issues'],
    ]);
}
```

---

### Phase 5: Add Rollback Capability (High, 1 day)

**5.1 Snapshot Service**
```php
// app/Services/CustomModules/ModuleInstallSnapshot.php
class ModuleInstallSnapshot {
    
    public function snapshotBefore(string $moduleName): array {
        return [
            'permissions' => DB::table('permissions')
                ->where('module', $moduleName)
                ->get()
                ->toArray(),
            
            'module_settings' => DB::table('module_settings')
                ->where('module', $moduleName)
                ->get()
                ->toArray(),
            
            'timestamp' => now()->toIso8601String(),
        ];
    }
    
    public function restoreFrom(string $moduleName, array $snapshot): void {
        // Delete current state
        DB::table('permissions')->where('module', $moduleName)->delete();
        DB::table('module_settings')->where('module', $moduleName)->delete();
        
        // Restore from snapshot
        if (!empty($snapshot['permissions'])) {
            DB::table('permissions')->insert($snapshot['permissions']);
        }
        if (!empty($snapshot['module_settings'])) {
            DB::table('module_settings')->insert($snapshot['module_settings']);
        }
    }
}
```

**5.2 Rollback Controller Route**
```php
// routes/custom-module-installer.overlay.php
Route::post('/admin/custom-modules/{install}/rollback', [CustomModuleController::class, 'rollback'])
    ->middleware('superadmin');

// CustomModuleController
public function rollback(ModuleInstallLog $install) {
    if (empty($install->snapshot)) {
        return Reply::dataOnly(['status' => 'fail', 'message' => 'No snapshot available']);
    }
    
    $moduleName = $install->module_name;
    
    // Delete module files
    File::deleteDirectory(base_path("Modules/{$moduleName}"));
    
    // Restore DB state
    app(ModuleInstallSnapshot::class)->restoreFrom($moduleName, $install->snapshot);
    
    // Clear caches
    Artisan::call('cache:clear');
    
    return Reply::dataOnly([
        'status' => 'success',
        'message' => "Module {$moduleName} has been rolled back",
    ]);
}
```

---

### Phase 6: Template Registry (Medium, 1 day)

**6.1 Create Template Manifest**
```php
// app/Services/CustomModules/TemplateRegistry.php
class TemplateRegistry {
    
    public const REQUIRED_TEMPLATES = [
        'install.blade.php' => 'Main upload & status view',
        'upload-list.blade.php' => 'List of uploaded modules',
        'results-panel.blade.php' => 'Installation result display',
    ];
    
    public const DIAGNOSTIC_TEMPLATES = [
        'menu-diff.blade.php' => 'Menu change preview',
        'permission-matrix.blade.php' => 'Permission mapping view',
        'route-truth.blade.php' => 'Route registration proof',
    ];
    
    public const REQUIRED_TEMPLATE_DATA = [
        'install.blade.php' => ['moduleFiles', 'uploadMaxFilesize', 'doctorSummaryCards'],
        'results-panel.blade.php' => ['analysis', 'status', 'message'],
        'permission-matrix.blade.php' => ['permissions', 'conflicts'],
    ];
    
    public static function validate($templateName, $data): void {
        if (!isset(self::REQUIRED_TEMPLATE_DATA[$templateName])) {
            return; // Optional template
        }
        
        $required = self::REQUIRED_TEMPLATE_DATA[$templateName];
        $missing = array_diff($required, array_keys($data));
        
        if (!empty($missing)) {
            throw new \Exception(
                "Template {$templateName} missing required data: " . implode(', ', $missing)
            );
        }
    }
}
```

**6.2 Update View Calls**
```blade
{{-- resources/views/custom-modules/install.blade.php --}}
@php
    TemplateRegistry::validate('install', $data);
@endphp

<div class="module-installer">
    {{-- Safe because data is validated --}}
</div>
```

---

### Phase 7: Upload Cleanup (Low, 0.5 day)

**7.1 Create Cleanup Command**
```php
// app/Console/Commands/CleanupModuleUploads.php
class CleanupModuleUploads extends Command {
    protected $signature = 'modules:cleanup-uploads {--days=7}';
    
    public function handle() {
        $uploadPath = config('froiden_envato.tmp_path');
        $days = (int) $this->option('days');
        $cutoff = now()->subDays($days)->timestamp;
        
        $deleted = 0;
        
        if (File::exists($uploadPath)) {
            foreach (File::files($uploadPath) as $file) {
                if ($file->getATime() < $cutoff) {
                    File::delete($file->getPathname());
                    $deleted++;
                }
            }
        }
        
        $this->info("Deleted {$deleted} old upload files");
    }
}
```

**7.2 Schedule It**
```php
// app/Console/Kernel.php
protected function schedule(Schedule $schedule) {
    $schedule->command('modules:cleanup-uploads --days=7')
        ->daily()
        ->at('03:00');
}
```

---

## Quick Wins (Do These First)

| Action | Time | Impact |
|--------|------|--------|
| Delete duplicate migrations | 5 min | Fixes schema ambiguity |
| Add PermissionCollisionValidator | 30 min | Prevents silent permission dupes |
| Add RouteCollisionValidator | 30 min | Prevents silent route dupes |
| Bind execute() to QueuePermissionRepairAction | 1 hour | Repairs actually work |
| Create SafeFixActionExecutor | 1.5 hours | Orchestrates all repairs |
| Add SecurityScanValidator | 1 hour | Blocks malicious uploads |
| Create ModuleInstallSnapshot + rollback | 1.5 hours | Can undo bad installs |
| **TOTAL** | **~6 hours** | **Blocks critical issues** |

---

## Data Flow (After Fixes)

```
Upload ZIP
    ↓
SecurityScanValidator (scan for shells)
    ↓ PASS
PermissionCollisionValidator (check existing keys)
    ↓ PASS
RouteCollisionValidator (check existing routes)
    ↓ PASS
ManifestValidator (ZIP structure)
    ↓ PASS
Snapshot system state (for rollback)
    ↓
File move to Modules/{ModuleName}
    ↓
SafeFixActionExecutor
    ├─ execute permission repair
    ├─ execute package bridge repair
    ├─ execute company settings repair
    └─ execute cache clear
    ↓
Record in custom_module_installs
    ↓
Return success + rollback URL
```

---

## Testing Checklist

```bash
# Unit tests
- PermissionCollisionValidator detects duplicates
- RouteCollisionValidator detects URI conflicts
- SecurityScanValidator blocks shell_exec patterns
- SafeFixActionExecutor executes all 4 actions

# Integration tests
- Full install flow works end-to-end
- Rollback restores pre-install state
- Partial failure (file ok, permission fails) is logged
- Can't rollback a module that has no snapshot

# Manual tests
- Upload valid module → installs
- Upload module with duplicate permission → blocked
- Upload module with duplicate route → blocked
- Upload ZIP with shell_exec → blocked
- Install → rollback → module gone
- Run cleanup-uploads command → old files deleted
```

---

## Summary: You Need This, Not CodeIgniter

**What's critical**:
1. ✅ Bind execute() to action classes (currently just describe())
2. ✅ Add collision validators (permissions + routes)
3. ✅ Add rollback capability (snapshot + restore)
4. ✅ Add security scanning (block shells, check ZIP integrity)
5. ✅ Fix duplicate migrations
6. ✅ Add upload cleanup

**What's optional but helpful**:
- Template registry (for maintainability)
- Enhanced logging
- Better error messages in UI

**Total effort**: ~2-3 days to make production-ready

That's it. No CodeIgniter. Just filling in the blanks in your existing Laravel architecture.
