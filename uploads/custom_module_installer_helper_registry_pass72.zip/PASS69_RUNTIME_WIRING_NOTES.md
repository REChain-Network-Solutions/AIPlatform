# Pass 69 Runtime Wiring Fixes

## Fixed
- Replaced missing event-class dispatcher dependency with direct repository-backed lifecycle logging.
- Added `ModuleInstallationLog` and `ModuleConfiguration` models required by the extensions package.
- Reworked `ConfigurationManager` to load nested runtime config safely from DB and JSON/YAML files.
- Fixed `AutomatedTestSuiteRunner` to accept nullable install IDs and to scan manifests from nested zip roots.
- Corrected dashboard controller imports and export path handling.
- Added migration to align `module_install_logs` and `module_installation_logs` with extension runtime fields.

## Why
Pass67 contained all files, but several extension services were not executable because of missing models, missing event classes, table-name mismatches, and a strict constructor type on the automated test runner.
