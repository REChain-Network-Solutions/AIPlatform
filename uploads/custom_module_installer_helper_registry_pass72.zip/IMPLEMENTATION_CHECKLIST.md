# Custom Module Installer - Implementation Checklist

## Pre-Integration (Do These First)

- [ ] Read `00_START_HERE_INTEGRATION_GUIDE.md`
- [ ] Read `UPGRADE_SUMMARY.md` for complete overview
- [ ] Backup database: `mysqldump -u root -p db_name > backup_$(date +%Y%m%d).sql`
- [ ] Git commit current code: `git commit -am "Pre-upgrade backup"`
- [ ] Verify all 9 new files exist in project:
  - [ ] `app/Services/CustomModules/Validators/PermissionCollisionValidator.php`
  - [ ] `app/Services/CustomModules/Validators/RouteCollisionValidator.php`
  - [ ] `app/Services/CustomModules/Validators/SecurityScanValidator.php`
  - [ ] `app/Services/CustomModules/SafeFixActionExecutor.php`
  - [ ] `app/Services/CustomModules/ModuleInstallSnapshot.php`
  - [ ] `app/Services/CustomModules/TemplateRegistry.php`
  - [ ] `app/Console/Commands/CleanupModuleUploads.php`
  - [ ] Database migration: `2026_03_24_000001_enhance_custom_module_installs_table.php`
  - [ ] `tests/Integration/CustomModules/CustomModuleInstallationTest.php`

## Step 1: Update Action Classes

These 4 files have been enhanced with execute() + rollback():
- [ ] Verify `QueuePermissionRepairAction.php` has execute() and rollback()
- [ ] Verify `QueueCacheClearAction.php` has execute() and rollback()
- [ ] Verify `QueuePackageBridgeRepairAction.php` has execute() and rollback()
- [ ] Verify `QueueCompanyModuleSettingsRepairAction.php` has execute() and rollback()

Status: ✅ Already completed (files updated in /home/claude)

## Step 2: Update Models

- [ ] Verify `ModuleInstallLog.php` has:
  - [ ] Proper JSON casts for new fields
  - [ ] Helper methods: `forModule()`, `latestForModule()`, `rollbackable()`
  - [ ] Attribute accessors: `getStatusLabelAttribute()`, `getStatusColorAttribute()`

Status: ✅ Already completed (file updated in /home/claude)

## Step 3: Update Routes

- [ ] Verify `routes/custom-module-installer.overlay.php` has:
  - [ ] New route: `POST /custom-modules/{install}/rollback`
  - [ ] Middleware: `superadmin`

Status: ✅ Already completed (file updated in /home/claude)

## Step 4: Update Controller

**Most Important Step** - Replace store() and add rollback() methods

- [ ] Open `CustomModuleController.php`
- [ ] Locate the `store()` method (currently ~80 lines)
- [ ] Replace with new version from `ENHANCED_STORE_METHOD.php` (~280 lines)
- [ ] Add these imports at top:
  ```php
  use App\Services\CustomModules\Validators\{
      PermissionCollisionValidator,
      RouteCollisionValidator,
      SecurityScanValidator,
  };
  use App\Services\CustomModules\SafeFixActionExecutor;
  use App\Services\CustomModules\ModuleInstallSnapshot;
  use App\Models\ModuleInstallLog;
  ```
- [ ] Add new `rollback()` method from `ROLLBACK_METHOD.php`
- [ ] Verify imports resolve without errors
- [ ] Check for syntax errors: `php artisan tinker` → exit

## Step 5: Update Kernel Scheduler

- [ ] Open `app/Console/Kernel.php`
- [ ] Find `schedule()` method
- [ ] Add cleanup schedule from `KERNEL_SCHEDULER_UPDATE.php`:
  ```php
  $schedule->command('modules:cleanup-uploads --days=7')
      ->daily()
      ->at('03:00');
  ```

## Step 6: Database Migration

- [ ] Run: `php artisan migrate`
- [ ] Verify success: `php artisan migrate:status` (should show no pending)
- [ ] Verify fields exist:
  ```php
  php artisan tinker
  > Schema::getColumnListing('module_install_logs')
  > // Should include: module_name, version, status, manifest_data, validation_results, etc
  ```

## Step 7: Cache & Optimization

- [ ] Clear caches: `php artisan optimize:clear`
- [ ] Verify routes: `php artisan route:list | grep custom-modules`
  - Should include: `POST custom-modules/{install}/rollback`

## Step 8: Testing

### Unit Tests
- [ ] Run all tests: `php artisan test tests/Integration/CustomModules/CustomModuleInstallationTest.php`
- [ ] Expected: 8 test cases, all pass

### Manual Tests (Must Do All)
- [ ] Test 1: Upload **valid** module → should install successfully
  - [ ] Files appear in Modules/{ModuleName}/
  - [ ] Log created with status='installed'
  - [ ] can_rollback=true
  - [ ] Response includes install_id and rollback_url
  
- [ ] Test 2: Upload module with **duplicate permission** → should block
  - [ ] First: Create a permission in DB with key 'test_perm', module 'Core'
  - [ ] Upload module with same permission key
  - [ ] Should get error: "Permission key collision"
  - [ ] Module NOT installed
  - [ ] Log created with status='install_blocked_collisions'
  
- [ ] Test 3: Upload module with **duplicate route** → should block
  - [ ] Upload module with route to existing path (e.g., /admin/settings)
  - [ ] Should get error: "Route collision"
  - [ ] Module NOT installed
  
- [ ] Test 4: Upload ZIP with **shell_exec** → should block
  - [ ] Create test module with PHP file containing `shell_exec()`
  - [ ] Should get error: "Dangerous pattern detected"
  - [ ] Module NOT installed
  
- [ ] Test 5: Install then **rollback** → should restore
  - [ ] Install valid module
  - [ ] Verify files exist in Modules/
  - [ ] POST to /custom-modules/{install_id}/rollback
  - [ ] Files gone from Modules/
  - [ ] Log status='rolled_back'
  
- [ ] Test 6: Cleanup command
  - [ ] Create old test ZIPs in upload directory
  - [ ] Run: `php artisan modules:cleanup-uploads --days=7`
  - [ ] Old files deleted, recent files kept
  
- [ ] Test 7: Verify permissions are created
  - [ ] Install module with permissions in manifest
  - [ ] Check permissions table: should have new records
  
- [ ] Test 8: Verify caches cleared
  - [ ] Install module
  - [ ] Check that cache:clear was called (should be in log)
  - [ ] Routes should be refreshed

## Step 9: Production Readiness Check

### Performance
- [ ] Measure install time: should be 3-5 seconds (was ~2s, now +1-2s for validators)
- [ ] Check disk usage: snapshots add ~10MB for each install
- [ ] Database: new fields don't impact query performance

### Security
- [ ] Verify SecurityScanValidator rejects shell_exec
- [ ] Verify PermissionCollisionValidator rejects duplicates
- [ ] Verify RouteCollisionValidator rejects conflicts
- [ ] Verify path traversal detection works

### Reliability
- [ ] Test partial failure: repairs succeed even if one fails
- [ ] Test snapshot capture: verify JSON stored correctly
- [ ] Test rollback on failed repair: system restores cleanly

### Logging
- [ ] Check laravel.log for install entries
- [ ] Verify ModuleInstallLog table is populated
- [ ] Verify repair results are recorded

## Step 10: Final Verification

- [ ] Run: `php artisan config:cache`
- [ ] Run: `php artisan route:cache`
- [ ] Restart queue worker (if using): `php artisan queue:restart`
- [ ] Check logs: `tail -f storage/logs/laravel.log`
- [ ] Load installation UI: /admin/module-settings → Custom Modules tab
- [ ] UI should load without errors
- [ ] Try uploading a test module through web interface

## Post-Integration

### Monitor First 24 Hours
- [ ] Watch laravel.log for errors
- [ ] Check ModuleInstallLog table for entries
- [ ] Verify cleanup command runs at scheduled time (3 AM)

### After 1 Week
- [ ] Spot-check a few installations
- [ ] Verify snapshots are being created
- [ ] Verify rollbacks work if needed
- [ ] Check disk space usage

### After 1 Month
- [ ] Review install statistics
- [ ] Measure performance impact
- [ ] Decide if any adjustments needed

## Documentation

### Keep These Files for Reference
- [ ] `00_START_HERE_INTEGRATION_GUIDE.md` - Overview
- [ ] `UPGRADE_SUMMARY.md` - Complete details
- [ ] `CORRECTED_DEEP_SCAN_PURE_LARAVEL.md` - Why changes were made
- [ ] `ENHANCED_STORE_METHOD.php` - Full store() code
- [ ] `ROLLBACK_METHOD.php` - Full rollback() code

### In Your Code
- [ ] Add comments to CustomModuleController::store() explaining the flow
- [ ] Document the rollback() method
- [ ] Link to validator classes in any team documentation

## Rollback Plan (If Something Goes Wrong)

If you need to revert all changes:

```bash
# 1. Restore database backup
mysql -u root -p your_database < backup_YYYYMMDD.sql

# 2. Revert controller changes
git checkout HEAD -- app/Http/Controllers/CustomModuleController.php

# 3. Revert model changes
git checkout HEAD -- app/Models/ModuleInstallLog.php

# 4. Revert routes
git checkout HEAD -- routes/custom-module-installer.overlay.php

# 5. Reset migrations (optional, only if migration causes issues)
php artisan migrate:rollback

# 6. Clear caches
php artisan optimize:clear
```

## Success Criteria

You're done when:
- ✅ All 10 steps completed
- ✅ All manual tests pass
- ✅ No errors in laravel.log
- ✅ ModuleInstallLog table has new data
- ✅ Can install modules
- ✅ Can rollback installations
- ✅ Cleanup command runs without errors

---

## Questions?

Refer to:
- **What?** → UPGRADE_SUMMARY.md
- **Why?** → CORRECTED_DEEP_SCAN_PURE_LARAVEL.md  
- **How?** → Code comments in each file
- **Stuck?** → Check Troubleshooting section in integration guide

**You've got this! 🚀**
