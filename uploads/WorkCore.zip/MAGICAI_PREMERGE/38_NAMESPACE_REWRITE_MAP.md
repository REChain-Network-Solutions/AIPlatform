# Namespace rewrite map

Goal: move WorkSuite app code under MagicAI/Titan-owned namespaces instead of dropping files into host root blindly.

- `app/Http/Controllers` -> `App\Http\Controllers\WorkSuite\<Domain>`
- `app/Models` -> `App\Models\WorkSuite\<Domain>`
- `app/Services` -> `App\Services\WorkSuite\<Domain>`
- `app/Events` -> `App\Events\WorkSuite\<Domain>`
- `app/Listeners` -> `App\Listeners\WorkSuite\<Domain>`
- `app/Observers` -> `App\Observers\WorkSuite\<Domain>`
- `app/Notifications` -> `App\Notifications\WorkSuite\<Domain>`
- `app/Console` -> `App\Console\Commands\WorkSuite`
- `app/DataTables` -> `App\DataTables\WorkSuite\<Domain>`
- `app/View/Components` -> `App\View\Components\WorkSuite\<Domain>`

Suggested domain folders:
- CRM -> `WorkSuite/Crm`
- Projects -> `WorkSuite/Projects`
- Finance -> `WorkSuite/Finance`
- HR -> `WorkSuite/Hr`
- Support -> `WorkSuite/Support`
- Platform/shared -> `WorkSuite/Shared`

Rule: keep host controllers/models untouched; import WorkSuite code under isolated namespaces first, then adapt route/model bindings incrementally.