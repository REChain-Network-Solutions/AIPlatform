# Preserved operations

This pass intentionally preserves operational depth for the cleaning MVP.

Kept in scope:
- leads + lead follow-ups
- customers + contacts + notes + files
- jobs + milestones + notes + files
- checklist/task engine
- attendance, leave, shifts, departments, designations
- estimates, invoices, payments, expenses, credit notes, taxes
- contracts/service agreements
- events/calendar for schedule & dispatch language
- internal messages/team chat
