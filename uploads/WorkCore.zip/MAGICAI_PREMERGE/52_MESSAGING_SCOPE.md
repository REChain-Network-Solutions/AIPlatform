# Messaging scope

Observed messaging implementation is internal/staff-oriented in this pre-merge pack.

MVP surface label:
- Messages -> Team Chat

Not claimed in this pass:
- omnichannel inbox
- customer-facing SMS/WhatsApp/Messenger threads
- Titan Omni style cross-channel orchestration

Those can be added later from existing source modules.
