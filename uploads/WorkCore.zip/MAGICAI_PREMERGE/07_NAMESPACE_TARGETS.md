# Namespace Targets

Recommended host-side placement based on the guide.

- Controllers -> `App\Http\Controllers\WorkSuite\...`
- Models -> `App\Models\WorkSuite\...`
- Services -> `App\Services\WorkSuite\...`
- Jobs -> `App\Jobs\WorkSuite\...`
- Events/Listeners -> `App\Events\WorkSuite`, `App\Listeners\WorkSuite`
- Routes -> `routes/worksuite.php`
- Views -> `resources/views/worksuite/...`
- Config -> `config/worksuite.php` only
