Overlay contents
================

New folder: magicai_overlay/
- app/Providers/WorkSuiteServiceProvider.php
- config/worksuite.php
- routes/worksuite.php
- README/INSTALL_ORDER.txt

This overlay is the first host-side starter kit for merging the cleaned
WorkSuite source into MagicAI.
