# Migration buckets

Keyword bucket count to guide slice-by-slice import into MagicAI.

- `project`: 20
- `task`: 14
- `invoice`: 20
- `estimate`: 6
- `lead`: 13
- `client`: 5
- `ticket`: 10
- `expense`: 4
- `leave`: 20
- `attendance`: 12
- `contract`: 6
- `message`: 0
- `notice`: 1
- `payment`: 6
- `employee`: 14
- `other`: 140
