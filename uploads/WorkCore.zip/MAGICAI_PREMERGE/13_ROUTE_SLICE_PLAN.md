# Route slice plan

- source route file: `routes/web.php`
- target host route pattern: `routes/core/*.routes.php` or `routes/extensions/*.routes.php`
- suggested middleware translation: `auth, multi-company-select, email_verified` -> host equivalents

## crm_clients_leads
- controllers: 19
  - `ClientController`
  - `ClientCategoryController`
  - `ClientContactController`
  - `ClientDocController`
  - `ClientNoteController`
  - `ClientSubCategoryController`
  - `DealController`
  - `DealNoteController`
  - `GdprController`
  - `GdprSettingsController`
  - `LeadBoardController`
  - `LeadCategoryController`
  - `LeadContactController`
  - `LeadCustomFormController`
  - `LeadFileController`
  - `LeadNoteController`
  - `LeadReportController`
  - `ProposalController`
  - `ProposalTemplateController`

## projects_tasks_time
- controllers: 36
  - `DiscussionController`
  - `DiscussionCategoryController`
  - `DiscussionFilesController`
  - `DiscussionReplyController`
  - `GanttLinkController`
  - `ProjectController`
  - `ProjectCalendarController`
  - `ProjectCategoryController`
  - `ProjectFileController`
  - `ProjectLabelController`
  - `ProjectMemberController`
  - `ProjectMilestoneController`
  - `ProjectNoteController`
  - `ProjectRatingController`
  - `ProjectSubCategoryController`
  - `ProjectTemplateController`
  - `ProjectTemplateMemberController`
  - `ProjectTemplateMilestoneController`
  - `ProjectTemplateSubTaskController`
  - `ProjectTemplateTaskController`
  - `ProjectTimelogBreakController`
  - `SubTaskController`
  - `SubTaskFileController`
  - `TaskController`
  - `TaskBoardController`
  - `TaskCalendarController`
  - `TaskCategoryController`
  - `TaskCommentController`
  - `TaskFileController`
  - `TaskLabelController`
  - `TaskNoteController`
  - `TaskReportController`
  - `TimelogController`
  - `TimelogCalendarController`
  - `TimelogReportController`
  - `TimelogWeeklyApprovalController`

## finance_sales
- controllers: 23
  - `BankAccountController`
  - `CreditNoteController`
  - `EstimateController`
  - `EstimateRequestController`
  - `EstimateTemplateController`
  - `ExpenseController`
  - `ExpenseCategoryController`
  - `ExpenseReportController`
  - `FinanceReportController`
  - `InvoiceController`
  - `InvoiceFilesController`
  - `InvoicePaymentDetailController`
  - `OrderController`
  - `PaymentController`
  - `ProductController`
  - `ProductCategoryController`
  - `ProductFileController`
  - `ProductSubCategoryController`
  - `QuickbookController`
  - `RecurringEventController`
  - `RecurringExpenseController`
  - `RecurringInvoiceController`
  - `RecurringTaskController`

## hr_people
- controllers: 18
  - `AppreciationController`
  - `AttendanceController`
  - `AttendanceReportController`
  - `DepartmentController`
  - `DesignationController`
  - `EmergencyContactController`
  - `EmployeeController`
  - `EmployeeDocController`
  - `EmployeeDocumentExpiryController`
  - `EmployeeShiftChangeRequestController`
  - `EmployeeShiftScheduleController`
  - `EmployeeVisaController`
  - `HolidayController`
  - `LeaveController`
  - `LeaveFileController`
  - `LeaveReportController`
  - `LeavesQuotaController`
  - `PromotionController`

## support_knowledge
- controllers: 12
  - `KnowledgeBaseController`
  - `KnowledgeBaseCategoryController`
  - `KnowledgeBaseFileController`
  - `MessageController`
  - `MessageFileController`
  - `NoticeController`
  - `NoticeFileController`
  - `NotificationController`
  - `TicketController`
  - `TicketCustomFormController`
  - `TicketFileController`
  - `TicketReplyController`

## calendar_contracts
- controllers: 10
  - `ContractController`
  - `ContractDiscussionController`
  - `ContractFileController`
  - `ContractRenewController`
  - `ContractTemplateController`
  - `ContractTypeController`
  - `EventCalendarController`
  - `EventFileController`
  - `MyCalendarController`
  - `WeeklyTimesheetController`

## system_misc
- controllers: 11
  - `AwardController`
  - `DashboardController`
  - `ImageController`
  - `ImportController`
  - `IncomeVsExpenseReportController`
  - `PassportController`
  - `SalesReportController`
  - `SearchController`
  - `SettingsController`
  - `StickyNoteController`
  - `UserPermissionController`
