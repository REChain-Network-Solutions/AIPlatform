# Cleaning vertical map

Default vertical for MVP: `cleaning`.

Surface remap:
- Clients -> Customers
- Projects -> Jobs
- Tasks -> Cleaning Checklist
- Tickets -> Service Requests
- Finance -> Money
- HR -> Team
- Time Logs -> Time on Job
- Knowledge Base -> Playbooks
- Contracts -> Service Agreements
- Messages -> Team Chat
- Calendar -> Schedule & Dispatch
- Reports -> Insights

Operational features preserved:
- follow-ups
- availability / shift roster
- attendance / shift log
- leave
- expenses
- payments
- credits
- recurring billing
- internal team chat
