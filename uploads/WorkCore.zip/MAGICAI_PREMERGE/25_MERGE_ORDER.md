# Merge order

1. CRM / leads / clients / deals
2. Projects / tasks / timelogs
3. Finance / estimates / invoices / payments
4. HR / attendance / leave / shifts
5. Tickets / messages / notices / knowledge
6. Shared primitives: custom fields, files, imports, notifications, calendar hooks
