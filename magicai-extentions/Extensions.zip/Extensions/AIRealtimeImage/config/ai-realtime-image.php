<?php

return [
    'api_key' => '111efed74c1516add84c73cc8f90d8be07dbb4d04fe31f61a1e89efdba3d6053',
];
