<?php

return [
    'version' => 1.0,
];
