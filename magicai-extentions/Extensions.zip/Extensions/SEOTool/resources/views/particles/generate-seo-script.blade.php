<script src="{{ custom_theme_url('/assets/js/panel/generateSEO.js') }}"></script>
